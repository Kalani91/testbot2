# -*- coding: utf-8 -*-
#
# Author: Chuan He
# Created on 30/03/2021
# Last edit: 22/04/2021

# This file stores mysql server access configuration
server = {
    "user": "bot",
    "password": "kPrDKkDL.WigvN4x",
    "host": "projectbotmysql.cxjfgwwghxos.us-east-1.rds.amazonaws.com",
    "port": 3306,
    "database": "cos60010"
}